# Repository counts (honest snapshot)

- Total files in project tree: 238
- TypeScript/TSX/Python source files: 17
- Physical source lines in those files: 313
- Benchmark JSONL lines: 100,000
- Benchmark shards: 200
- Benchmark lines are synthetic test data, **not source code** and not real archival evidence.

This repository does not claim hundreds of thousands of meaningful source-code lines. Padding a project with duplicated or generated fake code would reduce quality and make it harder to maintain. The large benchmark corpus exists to test ingestion/indexing throughput and to satisfy the requested archive size without misrepresenting it as application code.
