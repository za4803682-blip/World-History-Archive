#!/usr/bin/env python3
"""Generate synthetic JSONL shards for repeatable load testing; never real archive data."""
import argparse, base64, json, secrets
from pathlib import Path

def main():
 p=argparse.ArgumentParser(); p.add_argument('--records',type=int,default=100000); p.add_argument('--shards',type=int,default=200); p.add_argument('--payload-bytes',type=int,default=220); p.add_argument('--out',default='benchmarks/synthetic-load-corpus'); a=p.parse_args()
 if a.records<1 or a.shards<1 or a.shards>a.records or not 8<=a.payload_bytes<=4096: raise SystemExit('invalid corpus dimensions')
 out=Path(a.out); out.mkdir(parents=True,exist_ok=True); per=(a.records+a.shards-1)//a.shards; idx=0
 for shard in range(a.shards):
  path=out/f'shard-{shard+1:04d}.jsonl'
  with path.open('w',encoding='utf-8') as f:
   for _ in range(min(per,a.records-idx)):
    idx+=1; record={'id':f'bench-{idx:09d}','title':f'Synthetic archival record {idx}','media_type':['texts','movies','image','audio','software'][idx%5],'year':1900+(idx%127),'source':'synthetic-benchmark-only','payload_b64':base64.b64encode(secrets.token_bytes(a.payload_bytes)).decode('ascii')}
    f.write(json.dumps(record,separators=(',',':'))+'\n')
  if idx>=a.records: break
 print(f'generated {idx} synthetic records in {min(a.shards, (idx+per-1)//per)} shards at {out}')
if __name__=='__main__': main()
