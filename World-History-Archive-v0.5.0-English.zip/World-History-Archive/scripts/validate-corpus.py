#!/usr/bin/env python3
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'benchmarks' / 'synthetic-load-corpus'
files = sorted(root.glob('shard-*.jsonl'))
assert len(files) == 200, f'expected 200 shards, got {len(files)}'
count = 0
for file in files:
    with file.open(encoding='utf-8') as f:
        for line_number, line in enumerate(f, 1):
            obj = json.loads(line)
            assert isinstance(obj, dict), f'{file.name}:{line_number} not object'
            assert 'id' in obj and 'title' in obj, f'{file.name}:{line_number} missing fields'
            count += 1
assert count == 100_000, f'expected 100000 records, got {count}'
print(f'PASS: {len(files)} shards, {count:,} valid synthetic records')
