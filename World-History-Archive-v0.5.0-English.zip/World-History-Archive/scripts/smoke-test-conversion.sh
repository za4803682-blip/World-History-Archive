#!/usr/bin/env bash
set -euo pipefail
command -v ffmpeg >/dev/null
command -v libreoffice >/dev/null
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
ffmpeg -hide_banner -loglevel error -f lavfi -i color=c=black:s=160x120:d=1 -f lavfi -i anullsrc=r=44100:cl=stereo -shortest -c:v libx264 -c:a aac -movflags +faststart "$work/sample.mp4"
test -s "$work/sample.mp4"
printf 'NOVAM PDF conversion smoke test\n' > "$work/sample.txt"
libreoffice --headless --convert-to pdf --outdir "$work" "$work/sample.txt" >/dev/null 2>&1
test -s "$work/sample.pdf"
printf 'PASS: FFmpeg MP4 output and LibreOffice PDF output created.\n'
