# Release checklist

- [ ] Set production secrets in hosting secret manager.
- [ ] Add persistent database migrations and backup/restore drills.
- [ ] Configure rate limits and abuse protection on search and AI endpoints.
- [ ] Add authentication and role-based access control beyond the single admin token.
- [ ] Add key vault/KMS; rotate and audit provider keys.
- [ ] Review source terms, copyright, privacy, and takedown process.
- [ ] Implement file size/type limits, malware scanning, and safe content headers.
- [ ] Implement authorized conversion jobs and queue monitoring if required.
- [ ] Run typecheck, unit tests, build, browser tests, load tests, and security review.
- [ ] Confirm ZIP contains no secrets or node_modules.
