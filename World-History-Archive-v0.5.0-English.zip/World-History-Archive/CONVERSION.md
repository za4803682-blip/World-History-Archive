# World History Archive conversion service

`POST /api/convert` accepts multipart fields `file` and `target` (`mp4` or `pdf`). It requires `Authorization: Bearer $NOVAM_ADMIN_TOKEN`. Uploads are limited to 100 MiB and stored only in a temporary directory that is removed after processing.

- MP4 conversion requires FFmpeg on the server (`FFMPEG_PATH` may override the binary path).
- PDF conversion requires LibreOffice (`LIBREOFFICE_PATH` may override the binary path).
- Supported extensions are deliberately allow-listed. This endpoint converts user-uploaded files only; it does not fetch remote URLs or bypass source restrictions.
- Production deployments should move conversions to a worker queue, add per-user quotas, malware scanning, container isolation, and stronger authentication/rate limits.

The Docker runtime installs FFmpeg and LibreOffice Writer. The endpoint is implemented, and local smoke tests can validate the binaries, but the full Next.js API route still requires dependency installation and integration testing in the deployment environment.
