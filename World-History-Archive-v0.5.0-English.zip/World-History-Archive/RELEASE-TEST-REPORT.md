# World History Archive v0.5.0 — Verification report (2026-10-15)

## Verified in this environment

- ZIP archive integrity: `unzip -t` passed; no corrupt archive entries were reported.
- Benchmark corpus: `python3 scripts/validate-corpus.py` passed: 200 JSONL shards and 100,000 synthetic records.
- Conversion tools smoke test: `bash scripts/smoke-test-conversion.sh` passed for generating a sample MP4 with FFmpeg and a sample PDF with LibreOffice. This does not test the deployed Next.js conversion route.
- Node.js runtime available: v22.16.0; npm v10.9.2.
- Package contains a Next.js 15 / React 19 TypeScript app and scripts for typecheck, unit tests, lint, and production build.
- No claim is made here that production build or live service integrations passed.

## Not verified / blocked

- `node_modules` was absent. `npm install --ignore-scripts --no-audit --no-fund` did not complete within the available execution window. Consequently, `npm run typecheck`, `npm test`, `npm run lint`, and `npm run build` have NOT been verified in this run.
- Internet Archive live search/metadata access was not tested successfully in this run.
- OpenAI live analysis was not tested; a valid server-side `OPENAI_API_KEY`, billing/usage access, and outbound network access are required.
- Admin key vault, provider test endpoint, and conversion API have not been end-to-end tested in a running Next.js server in this run.
- Browser/mobile responsive behavior, production hosting, persistent storage, backups, rate limiting, authentication/roles, abuse protection, and load/security testing remain unverified or incomplete.

## Feature boundaries to understand before launch

- Internet Archive search returns catalog metadata and listed file links; it does not prove authenticity, truth, copyright permission, or permanent availability.
- AI analysis uses available text and archive metadata as leads; it is not an authoritative fact-check and uploaded images/files are not currently sent to a multimodal model.
- Download links are generated from listed Internet Archive metadata. Availability can change and source terms apply.
- Conversion supports selected uploaded media to MP4 and selected documents to PDF when FFmpeg/LibreOffice are installed. It is not a general conversion engine and is admin-token protected.
- Authenticated Internet Archive S3 upload is not implemented. The environment includes IA credential placeholders, but this must not be advertised as a working upload feature.
- APK scanning/sandboxing and automatic APK safety verification are not implemented. Do not tell users APK files are safe merely because they are listed.
- The 100,000-record corpus is synthetic benchmark data, not genuine archival material.

## Required launch gate

On the actual deployment environment with network access:

1. Install dependencies with `npm ci` (after committing a lockfile) or `npm install`.
2. Run `npm run typecheck`, `npm test`, `npm run lint`, and `npm run build`; fix all failures.
3. Set long random `NOVAM_ADMIN_TOKEN` and `NOVAM_ENCRYPTION_KEY`, and set `OPENAI_API_KEY` only in server-side secret settings. Never use `NEXT_PUBLIC_` for secrets or commit `.env.local`.
4. Test search, item details, file metadata/download checks, AI analysis, admin authorization, key vault, and conversion through the running app.
5. Test on the intended public host over HTTPS, mobile and desktop; add rate limiting, request size limits, monitoring, backup/recovery, and a takedown/rights process before broad public launch.

Status: **development build; not yet verified production-ready**.
