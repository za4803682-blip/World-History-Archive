# Source-linked download policy

World History Archive displays direct source links only for files returned by Internet Archive metadata. Files flagged as private/restricted are not offered. `/api/download-check` can re-check that a file name is listed in metadata before rendering a download action.

Important: metadata listing is not a universal copyright license and does not guarantee a file will remain available. The source's item page, access terms, and applicable law remain authoritative. World History Archive does not bypass login, DRM, paywalls, access controls, or licensing restrictions. APKs are not automatically trusted; verify provenance and scan before installation.
