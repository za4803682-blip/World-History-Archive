# World History Archive

English-first Next.js App Router + TypeScript project for source-linked archive discovery, file availability checks, and evidence-aware AI analysis.

## Implemented in this repository

- Next.js App Router, TypeScript, responsive English LTR interface.
- Internet Archive Advanced Search and per-item metadata lookup.
- Direct source links for files listed by metadata, with conservative filtering for metadata that flags restricted/private files. This is a metadata availability check, not a copyright-license determination.
- `/api/download-check` rechecks that the file is listed before exposing a download URL. This is not a legal license check; the source's terms remain authoritative.
- OpenAI-compatible AI analysis with optional multi-turn context. Analysis now searches Internet Archive for related metadata leads and passes those links to the model as preliminary evidence, not proof. It does not promise absolute truth or invent sources when no evidence is supplied.
- Admin status endpoint, encrypted key-vault API, and provider connection test endpoint protected by `NOVAM_ADMIN_TOKEN`.
- Server-side AES-256-GCM encrypted key vault at `.data/novam-secrets.enc`; `OPENAI_API_KEY` environment variable takes precedence over the stored `openai` key. The vault stores secrets at rest; the public Internet Archive search adapter does not require an IA key, and authenticated IA S3 upload is not implemented yet.
- Admin-protected `/api/convert` endpoint for uploaded files, using FFmpeg for MP4 and LibreOffice for supported document-to-PDF conversion when those binaries are installed.
- 100,000-record synthetic JSONL load corpus in 200 shards for benchmarking. The corpus is explicitly synthetic test data, not archival evidence.
- Docker configuration with FFmpeg and LibreOffice conversion binaries, GitHub Actions, environment example, and basic tests.

## Requirements

- Node.js 22+ and npm.
- Network access for Internet Archive metadata and optional AI API calls.
- Optional FFmpeg and LibreOffice binaries for conversion.

## Run locally

```bash
cp .env.example .env.local
# Set a random NOVAM_ADMIN_TOKEN of at least 24 characters. Add OPENAI_API_KEY only if you want live AI analysis.
npm install
npm run dev
```

## Checks

```bash
npm run typecheck
npm test
npm run lint
npm run build
```

## Local verification scripts

- `python3 scripts/validate-corpus.py` checks all 200 JSONL shards and verifies 100,000 synthetic records.
- `bash scripts/smoke-test-conversion.sh` creates a sample MP4 with FFmpeg and a sample PDF with LibreOffice.
- See `RELEASE-TEST-REPORT.md` for checks completed and checks blocked by network availability.

## Benchmark corpus

The corpus is for ingestion/search load testing only and must not be presented as genuine archive data. Regenerate it with `python3 scripts/generate_benchmark_corpus.py`.

## Conversion notes

See `CONVERSION.md`. Conversions process uploaded files only, have a 100 MiB input limit, and require server binaries. Production deployments should isolate conversion workers and add quotas, malware scanning, and full authentication.

## Security and rights

Never commit `.env.local`, API keys, the encryption key, `.data/`, or admin tokens. Back up the encrypted vault and its encryption key separately; losing the key makes stored values unrecoverable. A file appearing in source metadata does not guarantee copyright permission or perpetual availability. World History Archive does not bypass DRM, paywalls, login, or access restrictions. Scan APKs and verify their provenance before installation.

## Honest release status

This repository is a substantial development foundation, not a claim of production readiness or superiority to Internet Archive. External service connectivity, real conversions, and full build/tests must be run in the target environment before release. The benchmark corpus is synthetic data and is not code.

## OpenAI analysis and archive-linked search

Set `OPENAI_API_KEY` in the server runtime environment (or local `.env.local`) and choose a model supported by your OpenAI API account with `OPENAI_MODEL`. Do not commit `.env.local` and never expose the key through a `NEXT_PUBLIC_` variable. The analysis endpoint searches Internet Archive metadata for related records and returns those records with source-page links and listed downloadable files when available. These results are leads, not proof of a claim. A visible source file does not itself guarantee copyright permission, continuous availability, or conversion to MP4/PDF/APK. The interface links to formats actually listed by the source; conversion is a separate server-side operation requiring the relevant tools.

Create an OpenAI API key at https://platform.openai.com/api-keys. API usage may incur charges and is subject to account limits.
