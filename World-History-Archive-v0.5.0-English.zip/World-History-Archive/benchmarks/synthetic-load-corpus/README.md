# Synthetic archive search benchmark corpus

This is generated load-test data, not real Internet Archive records and not production content. Each JSONL record is intentionally randomized to approximate storage and indexing pressure. Use it to benchmark ingestion/search pipelines; do not present it as archival evidence. The corpus is split into shards to make parallel ingestion tests possible.

Generate a fresh corpus with `python3 scripts/generate_benchmark_corpus.py --records 100000 --shards 200 --payload-bytes 160`.
