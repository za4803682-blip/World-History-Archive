# World History Archive v0.5.0

- AI-assisted archive search now tries both a cleaned title/topic query and the original user request.
- Merges duplicate Internet Archive identifiers.
- Includes listed file names and formats in the evidence context sent to the model.
- Adds Arabic environment setup instructions.
- Search matches are candidates, not confirmation of truth, rights, or download availability.

Validation limitation: full Next.js build/typecheck requires installed npm dependencies and external service credentials; these are not claimed as passed.
