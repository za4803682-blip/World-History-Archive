# إعداد مفاتيح World History Archive بأمان

أنشئ Fileًا في جذر المشروع باسم `.env.local` (محليًا فقط) والصق:

```dotenv
# OpenAI API
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4.1-mini
OPENAI_BASE_URL=https://api.openai.com/v1

# Internet Archive S3 — اختياري للعمليات المدعومة
INTERNET_ARCHIVE_ACCESS_KEY=
INTERNET_ARCHIVE_SECRET_KEY=

# رموز Admin والتشفير: أنشئ قيمًا عشوائية طويلة خاصة بك
NOVAM_ADMIN_TOKEN=
NOVAM_ENCRYPTION_KEY=

NOVAM_PUBLIC_URL=http://localhost:3000
```

- لا تضع أي قيمة سرية داخل GitHub أو File ZIP.
- تأكد أن `.env.local` مستثنى في `.gitignore`.
- عند النشر، ضع المتغيرات في إعدادات Environment Variables لدى مزود الاستضافة.
- إذا ظهر مفتاح في Image أو محادثة، ألغِه وأنشئ بديلًا.
- الكود الحالي يقرأ OPENAI_API_KEY وOPENAI_MODEL وOPENAI_BASE_URL.
- البحث العام في Internet Archive عادة لا يحتاج مفاتيح S3؛ لا تضفها إلا لعمليات S3 المدعومة.
- إضافة المفتاح لا تثبت أن الاتصال يعمل؛ اختبر التطبيق مع اتصال إنترنت ومفتاح صالح.
