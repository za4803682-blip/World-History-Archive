# World History Archive architecture notes

```text
Browser (Next.js RTL UI)
  ├─ GET /api/search?q=... ── Internet Archive Advanced Search
  ├─ GET /api/item/:identifier ── Internet Archive metadata API
  └─ POST /api/analyze ── server-side AI provider adapter

Admin browser
  └─ GET /api/admin/status (Bearer NOVAM_ADMIN_TOKEN)

Planned production components
  ├─ PostgreSQL: normalized records, provenance, users, audit trail
  ├─ S3-compatible object storage: owned/authorized files and derivatives
  ├─ OpenSearch: full-text and faceted index
  ├─ Redis + worker queue: OCR, checksums, conversions, retryable jobs
  └─ KMS/secret manager: encrypted provider credentials and rotation
```

## Trust and provenance

Keep original URL, provider identifier, retrieval timestamp, checksum where a file is lawfully retrievable, rights/access status, and processing history. A checksum verifies byte-level identity, not truthfulness. AI summaries must link to source evidence and expose uncertainty.

## Download policy

The current adapter links only to files listed in the public metadata API. It does not fetch arbitrary URLs server-side, proxy private addresses, remove DRM, bypass authentication, or claim that every item is downloadable. The browser's download behavior can vary by source headers and mobile OS.
