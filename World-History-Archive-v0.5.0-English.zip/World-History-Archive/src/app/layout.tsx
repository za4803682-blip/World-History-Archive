import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = { title: "World History Archive", description: "A digital archive for source-linked discovery, research, and evidence-aware AI analysis.", applicationName: "World History Archive" };
export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return <html lang="en" dir="ltr"><body>{children}</body></html>;
}
