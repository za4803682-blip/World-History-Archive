import { NextRequest, NextResponse } from "next/server";
import { getItemFiles } from "@/lib/archive";
export async function GET(_req: NextRequest, ctx: { params: Promise<{ identifier: string }> }) {
  try { const { identifier } = await ctx.params; return NextResponse.json({ identifier, files: await getItemFiles(identifier) }); }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "تعذر جلب الFileات." }, { status: 400 }); }
}
