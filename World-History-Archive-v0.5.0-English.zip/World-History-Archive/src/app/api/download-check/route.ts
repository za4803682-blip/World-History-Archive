import { NextRequest, NextResponse } from "next/server";
import { getItemFiles } from "@/lib/archive";
export const runtime = "nodejs";
export async function GET(req: NextRequest) {
  const identifier = (req.nextUrl.searchParams.get("identifier") || "").trim();
  const filename = (req.nextUrl.searchParams.get("file") || "").trim();
  if (!identifier || !filename || filename.length > 800) return NextResponse.json({ error: "identifier وfile مطلوبان." }, { status: 400 });
  try {
    const files = await getItemFiles(identifier);
    const file = files.find(f => f.name === filename);
    if (!file) return NextResponse.json({ downloadable: false, reason: "الFile غير موجود في بيانات المصدر." }, { status: 404 });
    if (!file.downloadable) return NextResponse.json({ downloadable: false, reason: "بيانات المصدر تشير إلى قيود وصول." }, { status: 403 });
    return NextResponse.json({ downloadable: true, url: file.url, name: file.name, format: file.format || "unknown", size: file.size ?? null, source: "Internet Archive metadata" }, { headers: { "Cache-Control": "private, max-age=60" } });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "تعذر التحقق من الFile." }, { status: 502 }); }
}
