import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { getSecret } from "@/lib/secret-vault";
import { searchInternetArchive } from "@/lib/archive";
export const runtime = "nodejs";
function authorized(req: NextRequest) {
  const expected = process.env.NOVAM_ADMIN_TOKEN || "";
  const got = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  const a = Buffer.from(got), b = Buffer.from(expected);
  return expected.length >= 24 && a.length === b.length && timingSafeEqual(a, b);
}
export async function POST(req: NextRequest) {
  if (!authorized(req)) return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  const body = await req.json().catch(() => null);
  const provider = body?.provider;
  if (provider === "internet-archive") {
    try {
      const result = await searchInternetArchive("public domain", 1);
      return NextResponse.json({ ok: true, provider, message: "نجح الاتصال ببحث Internet Archive العام.", sampleResults: result.items.length });
    } catch (e) {
      return NextResponse.json({ ok: false, provider, message: e instanceof Error ? e.message : "فشل الاتصال." }, { status: 502 });
    }
  }
  const providerName = typeof provider === "string" ? provider : "openai";
  const key = process.env.OPENAI_API_KEY || await getSecret(providerName).catch(() => undefined);
  if (!key) return NextResponse.json({ ok: false, provider: providerName, message: "لا يوجد مفتاح مضبوط لهذا المزود." }, { status: 400 });
  const base = (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  try {
    const response = await fetch(`${base}/models`, { headers: { Authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(15000) });
    if (!response.ok) return NextResponse.json({ ok: false, provider: providerName, message: `رفض المزود الاتصال (HTTP ${response.status}).` }, { status: 502 });
    return NextResponse.json({ ok: true, provider: providerName, message: "نجح الاتصال بالمزود والتحقق من المفتاح." });
  } catch (e) {
    return NextResponse.json({ ok: false, provider: providerName, message: e instanceof Error ? e.message : "Connection failed بالمزود." }, { status: 502 });
  }
}
