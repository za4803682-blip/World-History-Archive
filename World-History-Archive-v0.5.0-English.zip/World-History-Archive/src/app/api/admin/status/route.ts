import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { getSecret, listSecretMetadata } from "@/lib/secret-vault";
function validToken(got: string, expected: string) { const a = Buffer.from(got); const b = Buffer.from(expected); return expected.length >= 24 && a.length === b.length && timingSafeEqual(a, b); }
export async function GET(req: NextRequest) {
  const expected = process.env.NOVAM_ADMIN_TOKEN || "";
  const got = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!validToken(got, expected)) return NextResponse.json({ error: "غير مصرح." }, { status: 401 });
  let vaultProviders: string[] = []; let vaultReady = false;
  try { vaultProviders = (await listSecretMetadata()).map(x => x.provider); vaultReady = true; } catch { /* Vault not configured or unavailable. */ }
  const storedOpenAI = vaultReady ? await getSecret("openai").catch(() => undefined) : undefined;
  return NextResponse.json({ app: "World History Archive", status: "running", providers: { internetArchivePublicSearch: true, ai: Boolean(process.env.OPENAI_API_KEY || storedOpenAI), s3: Boolean(process.env.S3_ENDPOINT && process.env.S3_ACCESS_KEY_ID && process.env.S3_SECRET_ACCESS_KEY), encryptedKeyVault: vaultReady }, vaultProviders, note: "لا تُرسل قيم الأسرار إلى المتصفح. البحث العام في Internet Archive لا يحتاج مفتاحًا؛ عمليات S3 أو الرفع المصادق عليها تحتاج تكاملًا منفصلًا." });
}
