import { NextRequest, NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { deleteSecret, listSecretMetadata, putSecret } from "@/lib/secret-vault";
export const runtime = "nodejs";
function authorized(req: NextRequest) {
 const expected=process.env.NOVAM_ADMIN_TOKEN||""; const got=(req.headers.get("authorization")||"").replace(/^Bearer\s+/i,""); const a=Buffer.from(got),b=Buffer.from(expected);
 return expected.length>=24 && a.length===b.length && timingSafeEqual(a,b);
}
export async function GET(req: NextRequest) {
 if(!authorized(req)) return NextResponse.json({error:"غير مصرح."},{status:401});
 try { return NextResponse.json({keys:await listSecretMetadata()}); }
 catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"تعذر قراءة مخزن المفاتيح."},{status:503}); }
}
export async function POST(req: NextRequest) {
 if(!authorized(req)) return NextResponse.json({error:"غير مصرح."},{status:401});
 const body=await req.json().catch(()=>null); if(!body||typeof body.provider!=="string"||typeof body.value!=="string") return NextResponse.json({error:"provider وvalue مطلوبان."},{status:400});
 try { await putSecret(body.provider,body.value); return NextResponse.json({ok:true,provider:body.provider,message:"تم حفظ السر مشفرًا. لن تُعاد قيمته في الاستجابة."}); }
 catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Could not save key."},{status:400}); }
}
export async function DELETE(req: NextRequest) {
 if(!authorized(req)) return NextResponse.json({error:"غير مصرح."},{status:401});
 const provider=req.nextUrl.searchParams.get("provider")||""; if(!provider) return NextResponse.json({error:"provider مطلوب."},{status:400});
 try { await deleteSecret(provider); return NextResponse.json({ok:true,provider}); }
 catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Could not delete key."},{status:503}); }
}
