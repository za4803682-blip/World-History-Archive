import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { analyzeClaim } from "@/lib/ai";
import { searchInternetArchive } from "@/lib/archive";
import type { Evidence } from "@/lib/types";
export const runtime = "nodejs";
const schema = z.object({ input: z.string().trim().min(5).max(20000), evidence: z.array(z.object({ source: z.string().max(300), url: z.string().url(), note: z.string().max(1000) })).max(10).optional(), history: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(6000) })).max(12).optional() });
export async function POST(req: NextRequest) {
  const raw = await req.json().catch(() => null); const parsed = schema.safeParse(raw);
  if (!parsed.success) return NextResponse.json({ error: "أدخل نصًا للتحليل (5 إلى 20,000 حرف) وسجل محادثة صالحًا." }, { status: 400 });
  try {
    // Treat archive search results as leads for review, not as proof by themselves.
    let archiveEvidence: Evidence[] = [];
    let archiveItems: Awaited<ReturnType<typeof searchInternetArchive>>["items"] = [];
    try {
      // Search both the user's full request and a cleaned title/topic query.
      // Search results are candidates, never proof of rights or authenticity.
      const rawInput = parsed.data.input.trim().replace(/[؟?!،,؛;]+/g, " ");
      const stopWords = new Set([
        "هات", "هاتي", "ابعت", "ابعتلي", "ابعتولي", "جيب", "جيبي", "عايز", "عاوزه",
        "عاوز", "أريد", "اريد", "ممكن", "من", "فضلك", "لو", "سمحت", "لي", "لنا",
        "فيلم", "الفيلم", "كتاب", "الكتاب", "Image", "صور", "فيديو", "الفيديو",
        "File", "Fileات", "تحميل", "نزّل", "نزل", "اعرض", "ابحث", "عن", "في",
        "internet", "archive", "archive.org"
      ]);
      const titleQuery = rawInput.split(/\s+/).filter(Boolean)
        .filter(word => !stopWords.has(word.toLowerCase())).join(" ").slice(0, 120);
      const fullQuery = rawInput.slice(0, 120);
      const queries = [...new Set([titleQuery, fullQuery].filter(q => q.length >= 2))].slice(0, 2);
      const batches = await Promise.allSettled(queries.map(q => searchInternetArchive(q, 1, true)));
      const seen = new Set<string>();
      for (const batch of batches) {
        if (batch.status !== "fulfilled") continue;
        for (const item of batch.value.items) {
          if (item.identifier && !seen.has(item.identifier)) {
            seen.add(item.identifier);
            archiveItems.push(item);
          }
        }
      }
      archiveItems = archiveItems.slice(0, 8);
      archiveEvidence = archiveItems.map(item => ({
        source: `Internet Archive: ${item.title}`,
        url: item.detailUrl,
        note: [item.description, item.creator ? `Creator: ${item.creator}` : "", item.year ? `Year: ${item.year}` : "", `Media type: ${item.mediatype}`, `Identifier: ${item.identifier}`, `Listed files: ${item.files.slice(0, 12).map(f => `${f.name} (${f.format || "unknown format"})`).join(", ")}`].filter(Boolean).join(" | ").slice(0, 1500)
      }));
    } catch { /* AI analysis can still explain that archive evidence could not be retrieved. */ }
    const supplied = parsed.data.evidence ?? [];
    const combined = [...archiveEvidence, ...supplied].slice(0, 10);
    const result = await analyzeClaim(parsed.data.input, combined, parsed.data.history ?? []);
    return NextResponse.json({ ...result, archiveItems, archiveSearch: { attempted: true, results: archiveEvidence.length, note: archiveEvidence.length ? "نتائج الأرشيف قرائن أولية ويجب فتح المصدر ومراجعة سياقه." : "تعذر جلب نتائج أرشيف؛ لا تعتبر غياب النتائج دليلًا على صحة الادعاء." } });
  }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "تعذر تنفيذ التحليل." }, { status: 502 }); }
}
