import { NextRequest, NextResponse } from "next/server";
import { searchInternetArchive } from "@/lib/archive";
export const runtime = "nodejs";
export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get("q") || "").trim();
  const page = Math.max(1, Math.min(100, Number(req.nextUrl.searchParams.get("page") || 1)));
  if (q.length < 2) return NextResponse.json({ error: "اكتب كلمتين على الأقل للبحث." }, { status: 400 });
  if (q.length > 180) return NextResponse.json({ error: "عبارة البحث طويلة جدًا." }, { status: 400 });
  try { return NextResponse.json(await searchInternetArchive(q, page), { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } }); }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "تعذر البحث في المصدر." }, { status: 502 }); }
}
