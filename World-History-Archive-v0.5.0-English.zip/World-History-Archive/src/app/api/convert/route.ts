import { NextRequest, NextResponse } from "next/server";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { randomUUID, timingSafeEqual } from "node:crypto";
export const runtime = "nodejs";
export const maxDuration = 120;
const MAX_BYTES = 100 * 1024 * 1024;
function authorized(req: NextRequest) {
  const expected = process.env.NOVAM_ADMIN_TOKEN || "";
  const got = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  const a = Buffer.from(got); const b = Buffer.from(expected);
  return expected.length >= 24 && a.length === b.length && timingSafeEqual(a, b);
}
function run(bin: string, args: string[], timeoutMs = 100_000): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { stdio: ["ignore", "ignore", "pipe"], windowsHide: true });
    let stderr = ""; const timer = setTimeout(() => { child.kill("SIGKILL"); reject(new Error("انتهت مهلة التحويل.")); }, timeoutMs);
    child.stderr.on("data", d => { stderr = (stderr + String(d)).slice(-3000); });
    child.on("error", err => { clearTimeout(timer); reject(err); });
    child.on("close", code => { clearTimeout(timer); if (code === 0) resolve(); else reject(new Error(`فشل التحويل (${code}): ${stderr.slice(-800)}`)); });
  });
}
export async function POST(req: NextRequest) {
  if (!authorized(req)) return NextResponse.json({ error: "يتطلب التحويل تصريح مدير صالحًا." }, { status: 401 });
  const form = await req.formData().catch(() => null);
  const file = form?.get("file"); const target = form?.get("target");
  if (!(file instanceof File) || (target !== "mp4" && target !== "pdf")) return NextResponse.json({ error: "أرسل Fileًا وحدد target=mp4 أو pdf." }, { status: 400 });
  if (file.size < 1 || file.size > MAX_BYTES) return NextResponse.json({ error: "حجم الFile يجب أن يكون أقل من 100 ميجابايت." }, { status: 413 });
  const ext = path.extname(file.name).toLowerCase();
  const allowedMedia = new Set([".mp4", ".mov", ".mkv", ".webm", ".avi", ".mpg", ".mpeg", ".m4v", ".mp3", ".wav", ".ogg", ".flac"]);
  const allowedDocs = new Set([".doc", ".docx", ".odt", ".rtf", ".txt", ".html"]);
  if (target === "mp4" && !allowedMedia.has(ext)) return NextResponse.json({ error: "نوع الFile غير مدعوم للتحويل إلى MP4." }, { status: 415 });
  if (target === "pdf" && !allowedDocs.has(ext)) return NextResponse.json({ error: "التحويل إلى PDF يدعم Documentات DOC/DOCX/ODT/RTF/TXT/HTML." }, { status: 415 });
  const work = await mkdtemp(path.join(tmpdir(), "novam-convert-"));
  try {
    const input = path.join(work, `input${ext}`); const output = path.join(work, `output.${target}`);
    await writeFile(input, Buffer.from(await file.arrayBuffer()), { flag: "wx" });
    if (target === "mp4") await run(process.env.FFMPEG_PATH || "ffmpeg", ["-nostdin", "-y", "-i", input, "-map", "0:v:0?", "-map", "0:a:0?", "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-movflags", "+faststart", output]);
    else await run(process.env.LIBREOFFICE_PATH || "libreoffice", ["--headless", "--convert-to", "pdf", "--outdir", work, input]);
    const actual = target === "pdf" ? path.join(work, "input.pdf") : output;
    const info = await stat(actual); if (info.size < 1 || info.size > 200 * 1024 * 1024) throw new Error("حجم الناتج غير مسموح.");
    const data = await readFile(actual); const headers = new Headers({ "Content-Type": target === "mp4" ? "video/mp4" : "application/pdf", "Content-Disposition": `attachment; filename="novam-${randomUUID()}.${target}"`, "Content-Length": String(data.length), "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    return new NextResponse(new Uint8Array(data), { headers });
  } catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "فشل التحويل.", hint: "يتطلب MP4 وجود FFmpeg، ويتطلب PDF وجود LibreOffice على الخادم." }, { status: 503 }); }
  finally { await rm(work, { recursive: true, force: true }).catch(() => {}); }
}
