export type ArchiveFile = { name: string; format?: string; size?: string | number; source: string; url: string; downloadable: boolean };
export type ArchiveItem = { identifier: string; title: string; description?: string; creator?: string; year?: string; mediatype?: string; source: string; detailUrl: string; files: ArchiveFile[] };
export type Evidence = { source: string; url: string; note: string };
