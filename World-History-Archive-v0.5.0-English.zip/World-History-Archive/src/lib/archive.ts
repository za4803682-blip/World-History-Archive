import type { ArchiveFile, ArchiveItem } from "@/lib/types";
const IA = "https://archive.org";
function safeText(v: unknown): string { return typeof v === "string" ? v : typeof v === "number" ? String(v) : ""; }
function isRestricted(file: Record<string, unknown>): boolean {
  const text = [file.source, file.access, file.private, file.name, file.format].map(safeText).join(" ").toLowerCase();
  return /access-restricted|private item|private|restricted|dark archive|original-archive/.test(text) || file.private === true;
}
function safeFileName(name: string): boolean {
  return !!name && !name.startsWith("/") && !name.split("/").some(p => p === ".." || p === ".") && !/[\u0000-\u001f]/.test(name);
}
function fileUrl(identifier: string, name: string): string {
  return `${IA}/download/${encodeURIComponent(identifier)}/${name.split("/").map(encodeURIComponent).join("/")}`;
}
export async function searchInternetArchive(q: string, page = 1, includeFiles = true): Promise<{ items: ArchiveItem[]; total: number }> {
  const clean = q.trim().replace(/[\r\n\u0000]/g, " ").slice(0, 180);
  if (clean.length < 2) throw new Error("Search query must contain at least 2 characters.");
  const params = new URLSearchParams({ q: `${clean} AND mediatype:(texts OR movies OR image OR audio OR software)`, fl: "identifier,title,description,creator,year,mediatype", rows: "20", page: String(Math.max(1, Math.min(100, page))), output: "json", sort: "downloads desc" });
  const response = await fetch(`${IA}/advancedsearch.php?${params}`, { headers: { "User-Agent": "World History Archive-Archive/1.0 (public metadata search)" }, next: { revalidate: 60 }, signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`Internet Archive search failed (${response.status})`);
  const json = await response.json(); const docs: Record<string, unknown>[] = json?.response?.docs ?? [];
  const items: ArchiveItem[] = await Promise.all(docs.map(async d => {
    const identifier = safeText(d.identifier); let files: ArchiveFile[] = [];
    if (includeFiles) { try { files = await getItemFiles(identifier); } catch { /* Metadata failure does not discard useful search metadata. */ } }
    return { identifier, title: safeText(d.title) || identifier, description: safeText(d.description).slice(0, 800), creator: safeText(d.creator), year: safeText(d.year), mediatype: safeText(d.mediatype), source: "Internet Archive", detailUrl: `${IA}/details/${encodeURIComponent(identifier)}`, files };
  }));
  return { items, total: Number(json?.response?.numFound ?? 0) };
}
export async function getItemFiles(identifier: string): Promise<ArchiveFile[]> {
  if (!/^[a-zA-Z0-9._-]{1,180}$/.test(identifier)) throw new Error("Invalid archive identifier");
  const r = await fetch(`${IA}/metadata/${encodeURIComponent(identifier)}`, { next: { revalidate: 120 }, signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error(`Metadata unavailable (${r.status})`);
  const data = await r.json(); const raw: Record<string, unknown>[] = Array.isArray(data.files) ? data.files : [];
  return raw.filter(f => {
    const name = safeText(f.name);
    return safeFileName(name) && !name.endsWith("_meta.xml") && !name.endsWith("_files.xml") && !name.endsWith("_archive.torrent") && !name.endsWith(".sqlite");
  }).slice(0, 1000).map(f => {
    const name = safeText(f.name); const format = safeText(f.format); const size = f.size as string | number | undefined;
    const restricted = isRestricted(f);
    // A listed file is only offered when metadata doesn't flag it as restricted.
    // The source page and its terms remain authoritative for rights and availability.
    return { name, format, size, source: IA, url: fileUrl(identifier, name), downloadable: !restricted };
  });
}
export function isAllowedInternetArchiveDownload(url: string): boolean {
  try { const u = new URL(url); return u.protocol === "https:" && u.hostname === "archive.org" && u.pathname.startsWith("/download/"); }
  catch { return false; }
}
