import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
type Vault = Record<string, { value: string; updatedAt: string }>;
function encryptionKey(): Buffer {
  const raw = process.env.NOVAM_ENCRYPTION_KEY || "";
  if (!raw) throw new Error("NOVAM_ENCRYPTION_KEY is not configured.");
  if (/^[a-f0-9]{64}$/i.test(raw)) return Buffer.from(raw, "hex");
  if (Buffer.byteLength(raw, "utf8") === 32) return Buffer.from(raw, "utf8");
  return scryptSync(raw, "World History Archive-secret-vault-v1", 32);
}
function filePath() { return process.env.NOVAM_SECRETS_FILE || path.join(process.cwd(), ".data", "novam-secrets.enc"); }
function encrypt(data: Vault): string {
  const iv = randomBytes(12); const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const body = Buffer.concat([cipher.update(JSON.stringify(data), "utf8"), cipher.final()]);
  return JSON.stringify({ version: 1, iv: iv.toString("base64"), tag: cipher.getAuthTag().toString("base64"), body: body.toString("base64") });
}
function decrypt(raw: string): Vault {
  const box = JSON.parse(raw); if (box.version !== 1) throw new Error("Unsupported vault version.");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(box.iv, "base64"));
  decipher.setAuthTag(Buffer.from(box.tag, "base64"));
  const text = Buffer.concat([decipher.update(Buffer.from(box.body, "base64")), decipher.final()]).toString("utf8");
  const parsed = JSON.parse(text); if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Invalid vault payload.");
  return parsed as Vault;
}
async function readVault(): Promise<Vault> {
  try { return decrypt(await readFile(filePath(), "utf8")); }
  catch (e) { if ((e as NodeJS.ErrnoException).code === "ENOENT") return {}; throw e; }
}
async function writeVault(data: Vault): Promise<void> {
  const dest = filePath(); const dir = path.dirname(dest); await mkdir(dir, { recursive: true, mode: 0o700 });
  const tmp = `${dest}.${process.pid}.${randomBytes(5).toString("hex")}.tmp`;
  await writeFile(tmp, encrypt(data), { mode: 0o600, flag: "wx" }); await rename(tmp, dest);
}
export async function listSecretMetadata() {
  const vault = await readVault();
  return Object.entries(vault).map(([provider, item]) => ({ provider, configured: Boolean(item.value), updatedAt: item.updatedAt }));
}
export async function putSecret(provider: string, value: string) {
  if (!/^[a-z0-9][a-z0-9._-]{1,63}$/i.test(provider)) throw new Error("Invalid provider identifier.");
  if (value.length < 8 || value.length > 4096) throw new Error("Secret length must be between 8 and 4096 characters.");
  const vault = await readVault(); vault[provider] = { value, updatedAt: new Date().toISOString() }; await writeVault(vault);
}
export async function deleteSecret(provider: string) {
  const vault = await readVault(); delete vault[provider]; await writeVault(vault);
}
export async function getSecret(provider: string): Promise<string | undefined> {
  const item = (await readVault())[provider]; return item?.value;
}
