import { describe, expect, it } from "vitest";
import { isAllowedInternetArchiveDownload } from "@/lib/archive";
describe("Internet Archive URL policy", () => {
  it("accepts only HTTPS archive.org download URLs", () => {
    expect(isAllowedInternetArchiveDownload("https://archive.org/download/item/file.pdf")).toBe(true);
    expect(isAllowedInternetArchiveDownload("http://archive.org/download/item/file.pdf")).toBe(false);
    expect(isAllowedInternetArchiveDownload("https://evil.example/download/item/file.pdf")).toBe(false);
    expect(isAllowedInternetArchiveDownload("https://archive.org/details/item")).toBe(false);
  });
});
