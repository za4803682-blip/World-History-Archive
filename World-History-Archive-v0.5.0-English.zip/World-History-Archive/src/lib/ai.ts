import type { Evidence } from "@/lib/types";
import { getSecret } from "@/lib/secret-vault";
export type ChatTurn = { role: "user" | "assistant"; content: string };
export async function analyzeClaim(input: string, evidence: Evidence[] = [], history: ChatTurn[] = []) {
  const apiKey = process.env.OPENAI_API_KEY || await getSecret("openai").catch(() => undefined);
  const base = (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
  const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
  if (!apiKey) return { configured: false, answer: "لم يتم إعداد AI provider بعد. أضف OPENAI_API_KEY في إعدادات الخادم لتفعيل التحليل الحقيقي. لم يتم التحقق من صحة الادعاء.", evidence, status: "needs_provider" as const };
  const system = `You محلل أدلة رقمي وصحفي. لا تدّعِ اليقين المطلق. فرّق بين حقيقة موثقة وادعاء واستنتاج. لا تختلق مصادر أو روابط. إذا كانت الأدلة غير كافية فقل ذلك. أجب بالعربية مع: خلاصة، ما تدعمه الأدلة، ما لا يزال غير محسوم، والخطوات التالية. الأدلة المتاحة: ${JSON.stringify(evidence).slice(0, 12000)}`;
  const turns = history.slice(-12).map(t => ({ role: t.role, content: t.content.slice(0, 6000) }));
  const response = await fetch(`${base}/chat/completions`, { method: "POST", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" }, body: JSON.stringify({ model, temperature: 0.2, messages: [{ role: "system", content: system }, ...turns, { role: "user", content: input.slice(0, 20000) }] }), signal: AbortSignal.timeout(45000) });
  if (!response.ok) throw new Error(`AI provider error (${response.status})`);
  const json = await response.json(); const answer = json?.choices?.[0]?.message?.content;
  return { configured: true, answer: typeof answer === "string" ? answer : "لم يُرجع مزود الذكاء الاصطناعي إجابة نصية.", evidence, status: "analysis" as const };
}
